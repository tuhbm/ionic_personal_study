"use strict";
const module1_1 = require("./module1");
let m1 = new module1_1.MyClass();
m1.test1();
//# sourceMappingURL=using.js.map