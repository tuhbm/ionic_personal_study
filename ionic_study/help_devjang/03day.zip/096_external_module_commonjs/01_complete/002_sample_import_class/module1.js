"use strict";
class MyClass {
    constructor() {
    }
    test1() {
        console.log("MyClass.test1");
    }
}
exports.MyClass = MyClass;
//# sourceMappingURL=module1.js.map