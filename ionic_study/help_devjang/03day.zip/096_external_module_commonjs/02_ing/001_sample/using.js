define(["require", "exports", "./module1"], function (require, exports, module1_1) {
    "use strict";
    console.log(module1_1.test1());
});
//# sourceMappingURL=using.js.map