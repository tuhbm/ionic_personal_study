console.log(u.test1());
console.log(u.newtest2());
console.log(u.test3());
