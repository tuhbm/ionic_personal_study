var count=0;
export function test1() {
    count++;
    return "count ="+count;
}