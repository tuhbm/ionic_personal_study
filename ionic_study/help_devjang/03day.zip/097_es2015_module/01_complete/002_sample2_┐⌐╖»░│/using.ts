// 여러개의 export 내용을 u라는 오브젝트에 묶어서 사용
import  * as u from "./module1";
console.log(u.test1());
console.log(u.newtest2());
console.log(u.test3());