// export default 가  2개인 경우 에러
export default function() {
    return "test1"
}

export default  function() {
    return "test2"
}
