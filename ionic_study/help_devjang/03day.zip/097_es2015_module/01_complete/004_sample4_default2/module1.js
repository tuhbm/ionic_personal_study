"use strict";
// export default 가  2개인 경우 에러
function default_1() {
    return "test1";
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
function default_2() {
    return "test2";
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_2;
