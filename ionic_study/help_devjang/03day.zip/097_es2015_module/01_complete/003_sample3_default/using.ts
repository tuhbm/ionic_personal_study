// export default 내용
import  test1, {newtest2, test3 as newtest3} from "./module1";
console.log(test1());
console.log(newtest2());
console.log(newtest3());