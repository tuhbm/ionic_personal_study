"use strict";
var mypackage_1 = require("./mypackage");
var my1 = new mypackage_1.myPackage.MyClass1();
my1.method1();
