import {myPackage as myp} from "./mypackage";

let my1 = new myp.MyClass1();
my1.method1();