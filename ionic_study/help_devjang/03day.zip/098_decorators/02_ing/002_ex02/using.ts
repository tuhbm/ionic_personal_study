//??
//??
class MyClass {
    test1() {
       console.log("test1");
    }
}

let a1:any = new MyClass();


//??a1.test2();