//??
class MyClass {
    //??
    test1():void {
       console.log("test1");
    }
}

let a1:MyClass = new MyClass();
a1.test1();
