/// <reference path="mypackage.ts" />
var my1 = new myPackage.MyClass1();
my1.method1();
//접근 에러
//let my2 = new myPackage.MyClass2(); 
