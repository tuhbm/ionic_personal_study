??

var m1 = new  module1.MyClass();
m1.test1();
