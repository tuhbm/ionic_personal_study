import {test1} from "./module1";
alert(test1());