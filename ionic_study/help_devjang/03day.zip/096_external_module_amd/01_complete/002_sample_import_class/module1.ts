export class MyClass{
    constructor(){

    }

    test1(){
        console.log("MyClass.test1")
    }
}

