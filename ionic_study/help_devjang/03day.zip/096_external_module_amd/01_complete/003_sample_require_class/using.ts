import module1 = require("./module1");

var m1 = new  module1.MyClass();
m1.test1();
