define(["require", "exports", "./module1"], function (require, exports, module1) {
    "use strict";
    var m1 = new module1.MyClass();
    m1.test1();
});
//# sourceMappingURL=using.js.map