define(["require", "exports"], function (require, exports) {
    "use strict";
    class MyClass {
        constructor() {
            console.log("MyClass___________");
        }
        test1() {
            console.log("MyClass.test1");
        }
    }
    exports.MyClass = MyClass;
});
//# sourceMappingURL=module1.js.map