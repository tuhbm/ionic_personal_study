export class MyClass{
    constructor(){
        console.log("MyClass___________");
    }

    test1(){
        console.log("MyClass.test1");

    }
}

