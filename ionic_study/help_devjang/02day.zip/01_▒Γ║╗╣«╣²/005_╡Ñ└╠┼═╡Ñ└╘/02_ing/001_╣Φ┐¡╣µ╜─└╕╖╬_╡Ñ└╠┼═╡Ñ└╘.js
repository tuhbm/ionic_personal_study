'use strict';
console.log("1. ", a1, b1, c1);
console.log("2. ", a2, b2);
test1(["ddandongne", 1000]);
//# sourceMappingURL=001_배열방식으로_데이터데입.js.map