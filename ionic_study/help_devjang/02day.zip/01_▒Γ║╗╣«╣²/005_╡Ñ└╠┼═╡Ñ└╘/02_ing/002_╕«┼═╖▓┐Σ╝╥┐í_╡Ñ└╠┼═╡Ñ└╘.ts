/*
// es6
var a=10, b =20, c=30;
var obj = {a,b,c};
console.log("2.", obj);
*/




