declare  function test1()
declare  function test2():string