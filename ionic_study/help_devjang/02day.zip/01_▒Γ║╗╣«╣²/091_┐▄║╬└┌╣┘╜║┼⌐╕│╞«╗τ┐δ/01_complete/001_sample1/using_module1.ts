/// <reference path = "./module1.d.ts"/>
test1();
var va1:string=test2();
console.log("va1 = "+va1);