function test1() {
    console.log("test1");
}
function test2() {
    return "test2리턴값";
}
//# sourceMappingURL=module1.js.map