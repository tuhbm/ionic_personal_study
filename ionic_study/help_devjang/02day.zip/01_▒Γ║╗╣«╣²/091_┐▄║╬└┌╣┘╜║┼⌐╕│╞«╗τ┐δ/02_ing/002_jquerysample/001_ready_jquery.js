///<reference path="jquery.d.ts" />
//# sourceMappingURL=001_ready_jquery.js.map