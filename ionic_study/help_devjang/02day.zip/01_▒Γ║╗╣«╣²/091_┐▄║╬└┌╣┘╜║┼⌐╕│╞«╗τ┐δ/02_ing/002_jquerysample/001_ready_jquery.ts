///<reference path="jquery.d.ts" />

