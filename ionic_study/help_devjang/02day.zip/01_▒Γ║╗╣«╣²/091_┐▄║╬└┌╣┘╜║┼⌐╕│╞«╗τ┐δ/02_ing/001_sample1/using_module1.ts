/// <reference path = "./module1.d.ts"/>
