/*
변수에서 데이터 타입
*/


// 2. 타입스크립트 변수 선언
var data3:number=10;
data3="ddd";
console.log(data3);
