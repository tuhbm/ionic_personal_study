// 1. 함수 매개변수와 리턴값
function test1(value){
    console.log("value="+value);
}

test1(10);


function test2(value1,value2){
    return value1+value2;
}

var result=test2(10,20);
