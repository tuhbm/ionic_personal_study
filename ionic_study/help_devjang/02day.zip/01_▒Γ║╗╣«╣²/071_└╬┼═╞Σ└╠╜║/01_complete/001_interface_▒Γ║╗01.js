class ImageSlider {
    constructor() {
    }
    // 다음 메서드를 구현해야 합니다.
    effect() {
        console.log("effect");
    }
}
let a = new ImageSlider();
a.effect();
let b = new ImageSlider();
b.effect();
//# sourceMappingURL=001_interface_기본01.js.map