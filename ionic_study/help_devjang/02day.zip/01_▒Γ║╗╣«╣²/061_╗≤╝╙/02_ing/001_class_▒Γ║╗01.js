class MyParent {
    // 생성자
    constructor(data) {
        // 프로퍼티
        this.property1 = data;
    }
    method1() {
        console.log("MyParent.method1() " + this.property1);
    }
    method2() {
        console.log("MyParent.method1() " + this.property1);
    }
}
//# sourceMappingURL=001_class_기본01.js.map