'use strict';
let data:string[] = ["test1", "test2", "test3"];

for( let value of data){
    console.log(value);
}