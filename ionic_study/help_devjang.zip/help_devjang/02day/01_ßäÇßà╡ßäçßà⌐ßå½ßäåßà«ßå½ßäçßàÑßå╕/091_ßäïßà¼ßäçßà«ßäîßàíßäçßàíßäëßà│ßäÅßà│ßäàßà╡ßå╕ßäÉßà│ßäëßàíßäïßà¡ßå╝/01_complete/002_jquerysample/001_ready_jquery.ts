///<reference path="jquery.d.ts" />

$(document).ready(()=>{
    console.log("QQQQ");
    $("#target").html("이렇게 실행되요.");
})
