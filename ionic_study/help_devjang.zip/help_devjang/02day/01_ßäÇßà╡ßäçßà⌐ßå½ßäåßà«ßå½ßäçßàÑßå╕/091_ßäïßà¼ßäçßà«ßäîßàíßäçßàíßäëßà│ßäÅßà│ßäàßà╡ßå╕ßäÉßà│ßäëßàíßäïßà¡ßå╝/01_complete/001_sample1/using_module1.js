/// <reference path = "./module1.d.ts"/>
test1();
var va1 = test2();
console.log("va1 = " + va1);
//# sourceMappingURL=using_module1.js.map