/// <reference path = "./module1.d.ts"/>
//# sourceMappingURL=using_module1.js.map