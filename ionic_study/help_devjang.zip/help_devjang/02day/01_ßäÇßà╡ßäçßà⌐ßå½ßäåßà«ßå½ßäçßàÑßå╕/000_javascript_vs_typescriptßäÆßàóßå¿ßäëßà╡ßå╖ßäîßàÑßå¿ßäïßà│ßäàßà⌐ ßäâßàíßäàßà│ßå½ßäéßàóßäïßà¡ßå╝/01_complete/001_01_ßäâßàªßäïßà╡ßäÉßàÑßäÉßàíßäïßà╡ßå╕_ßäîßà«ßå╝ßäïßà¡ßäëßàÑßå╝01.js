/**
 * Created by ddandongne on 2016. 8. 12..
 */
var data1=10;
data1="value1";