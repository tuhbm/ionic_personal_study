'use strict';
var data = ["test1", "test2", "test3"];
for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
    var value = data_1[_i];
    console.log(value);
}
//# sourceMappingURL=001_sample.js.map