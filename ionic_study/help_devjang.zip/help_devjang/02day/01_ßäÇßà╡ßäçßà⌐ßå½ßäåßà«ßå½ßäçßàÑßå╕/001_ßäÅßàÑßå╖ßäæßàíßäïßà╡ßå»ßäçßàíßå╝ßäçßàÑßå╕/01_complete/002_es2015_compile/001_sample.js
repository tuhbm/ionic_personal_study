'use strict';
let data = ["test1", "test2", "test3"];
for (let value of data) {
    console.log(value);
}
//# sourceMappingURL=001_sample.js.map