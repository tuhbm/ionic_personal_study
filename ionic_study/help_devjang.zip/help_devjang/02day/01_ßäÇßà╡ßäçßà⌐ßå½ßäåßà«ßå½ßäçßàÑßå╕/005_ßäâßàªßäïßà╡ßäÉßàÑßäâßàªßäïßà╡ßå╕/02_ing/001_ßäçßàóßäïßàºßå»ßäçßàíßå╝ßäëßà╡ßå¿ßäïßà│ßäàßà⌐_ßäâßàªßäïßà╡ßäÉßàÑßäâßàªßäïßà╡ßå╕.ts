'use strict';
/*
es6
var [a,b,c] = [10,20,30];
console.log("1. es6", a,b,c);
*/
??
console.log("1. ", a1,b1,c1);

// 데이터 값을 건너 뛸수도 있음.
/*
var [a,,b]=[10,20,30];
console.log("5. es6", a,b);
*/
??
console.log("2. ", a2,b2);


??

test1(["ddandongne", 1000]);