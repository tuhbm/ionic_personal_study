'use strict';
//Boolean


//Number


//String


//Array


//Tuple(튜플

// 주의사항


//Enum (열거형)



// Any


// 데이터 타입을 넣지 않는 경우 자동으로 데이터 타입 설정




// 숫자 또는 문자열만 저장 가능

