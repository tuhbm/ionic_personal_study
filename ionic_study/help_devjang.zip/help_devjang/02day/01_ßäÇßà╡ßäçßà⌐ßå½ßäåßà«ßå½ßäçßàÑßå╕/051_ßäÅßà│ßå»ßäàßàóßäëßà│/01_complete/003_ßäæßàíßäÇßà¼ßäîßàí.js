/*
생성자 :
인스턴스가 생성될 때 자동으로 호출되는 메서드
constructor(){

}
파괴자 :
인스턴스가 사라질 때 자동으로 호출되는 메서드
없음
*/ 
//# sourceMappingURL=003_파괴자.js.map