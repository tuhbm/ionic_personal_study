function test1(arg1) {
    return arg1;
}
console.log("test1 = ", test1(10));
console.log("test1 = ", test1("sample"));
