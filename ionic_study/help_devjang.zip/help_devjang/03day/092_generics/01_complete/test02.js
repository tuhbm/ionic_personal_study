function test1(arg1, arg2) {
    var va1 = arg2;
    return arg1 + va1;
}
console.log("test1 = ", test1(10, 20));
