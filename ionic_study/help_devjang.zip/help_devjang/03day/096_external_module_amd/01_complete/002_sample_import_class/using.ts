import {MyClass} from "./module1";

let m1 = new MyClass();
m1.test1();