define(["require", "exports", "./module1"], function (require, exports, module1_1) {
    "use strict";
    let m1 = new module1_1.MyClass();
    m1.test1();
});
//# sourceMappingURL=using.js.map