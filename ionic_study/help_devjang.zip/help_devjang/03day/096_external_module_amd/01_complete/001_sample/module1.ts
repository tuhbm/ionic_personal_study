var count:number=0;
export function test1():string {
    count++;
    return "count ="+count;
}
