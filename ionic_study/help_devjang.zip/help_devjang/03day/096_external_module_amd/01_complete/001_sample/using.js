define(["require", "exports", "./module1"], function (require, exports, module1_1) {
    "use strict";
    alert(module1_1.test1());
});
//# sourceMappingURL=using.js.map