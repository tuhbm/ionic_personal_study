//??
class MyClass {
    //??
    test1() {
        console.log("test1");
    }
}
let a1 = new MyClass();
a1.test1();
//# sourceMappingURL=using.js.map