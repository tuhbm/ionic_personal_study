from;
"./module1";
console.log(test1());
console.log(newtest2());
console.log(newtest3());
