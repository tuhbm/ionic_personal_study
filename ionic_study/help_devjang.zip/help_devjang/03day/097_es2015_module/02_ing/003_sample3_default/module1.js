"use strict";
function () {
    return "test1";
}
function test2() {
    return "test2";
}
exports.newtest2 = test2;
function test3() {
    return "test3";
}
exports.test3 = test3;
