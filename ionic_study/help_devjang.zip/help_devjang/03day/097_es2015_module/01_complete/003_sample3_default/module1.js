"use strict";
function default_1() {
    return "test1";
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
function test2() {
    return "test2";
}
exports.newtest2 = test2;
function test3() {
    return "test3";
}
exports.test3 = test3;
