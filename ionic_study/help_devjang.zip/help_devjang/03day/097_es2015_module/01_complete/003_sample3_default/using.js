"use strict";
// export default 내용
var module1_1 = require("./module1");
console.log(module1_1.default());
console.log(module1_1.newtest2());
console.log(module1_1.test3());
