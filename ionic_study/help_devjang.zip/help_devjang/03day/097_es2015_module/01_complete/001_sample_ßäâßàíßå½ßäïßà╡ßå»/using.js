"use strict";
var module1_1 = require("./module1");
console.log(module1_1.test1());
