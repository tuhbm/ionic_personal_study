import {test1} from "./module1";
console.log(test1());
