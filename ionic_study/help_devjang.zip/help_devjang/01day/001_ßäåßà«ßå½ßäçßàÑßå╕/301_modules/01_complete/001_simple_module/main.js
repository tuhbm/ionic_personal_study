import m1 from "./module1";
console.log("Test2", m1);