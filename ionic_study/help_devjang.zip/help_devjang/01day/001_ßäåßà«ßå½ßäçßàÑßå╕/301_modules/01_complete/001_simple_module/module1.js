export default class MyClass{
    constructor(){
        console.log("MyClass");
    }

    method1(){
        console.log("method1()");
    }
}